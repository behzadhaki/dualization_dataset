<img width="469" alt="Screen Shot 2021-06-26 at 5 21 11 PM" src="https://user-images.githubusercontent.com/35939495/123517723-ecc03e80-d6a2-11eb-89c6-c8682b1522d1.png">
4 repetition sessions (1 hour each) with individual drummers.  24 tracks extracted from Luis’ repetition session with a balanced selection of genre.  Each track repeated 3 times and randomised.  
